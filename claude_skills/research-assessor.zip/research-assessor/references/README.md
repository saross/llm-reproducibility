# Research Assessor - Reference Documentation

This directory contains the complete extraction workflow documentation, schema definitions, checklists, and examples.

## Directory Structure

```
references/
├── workflow/          # Complete extraction prompts for each pass
├── schema/            # JSON schema and documentation
├── checklists/        # Decision frameworks and guidelines
└── examples/          # Worked examples from real extractions
```

## Workflow Files

The `workflow/` directory contains five complete extraction prompts:

1. **claims-pass1.md** - Liberal claims/evidence extraction (~800 lines)
2. **claims-pass2.md** - Claims/evidence rationalization (~900 lines)
3. **rdmap-pass1.md** - Liberal RDMAP extraction (~1000 lines)
4. **rdmap-pass2.md** - RDMAP rationalization (~900 lines)
5. **validation-pass3.md** - Integrity validation (~600 lines)

**Note:** These prompts are comprehensive (4000+ total lines) and contain:
- Complete extraction philosophy
- Detailed decision frameworks
- Extensive examples
- Expected information checklists
- Quality criteria
- Output specifications

## Schema Documentation

The `schema/` directory contains:
- **schema-guide.md** - Human-readable schema documentation
- **schema-v2.4-claims.json** - Claims/evidence object definitions
- **schema-v2.4-rdmap.json** - RDMAP object definitions
- **examples/** - JSON examples from real extractions

## Checklists

The `checklists/` directory provides decision support:
- **tier-assignment-guide.md** - Design vs Method vs Protocol decisions
- **consolidation-patterns.md** - When to lump vs split
- **expected-information.md** - Domain-specific completeness criteria

## Examples

The `examples/` directory contains worked extractions:
- **sobotkova-methods.md** - Complete RDMAP extraction example
- **claims-examples.md** - Claims and evidence examples
- **cross-reference-examples.md** - How to link objects

## Usage Pattern

When Claude encounters a task:
1. SKILL.md identifies which pass is needed
2. Claude reads the appropriate workflow file (e.g., `workflow/claims-pass1.md`)
3. If uncertain about decisions, Claude consults relevant checklists
4. If uncertain about schema structure, Claude reads schema-guide.md
5. If needing examples, Claude reviews examples directory

## Progressive Disclosure

Files are organized to minimize context loading:
- SKILL.md (~100 tokens at startup)
- Specific workflow file (~4,000-5,000 tokens when needed)
- Supporting references only as needed

This ensures efficient token usage while providing comprehensive guidance.
