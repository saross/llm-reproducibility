# Research Assessor - Reference Documentation

This directory contains decision frameworks, schema definitions, and examples to support the extraction workflow.

## Directory Structure

```
references/
├── schema/            # JSON schema and documentation
├── checklists/        # Decision frameworks and guidelines
└── examples/          # Worked examples from real extractions
```

## Architecture Note

**Extraction prompts are NOT included in this skill package.** The user provides detailed extraction prompts at runtime. This skill provides the supporting reference materials needed during extraction.

## What's Included

### Schema Documentation (`schema/`)

Complete object structure definitions:
- **schema-guide.md** - Human-readable schema documentation for all six object types
- Defines: evidence, claims, implicit_arguments, research_designs, methods, protocols
- Field requirements, enumerations, cross-reference patterns

### Decision Frameworks (`checklists/`)

Core decision support for extraction:
- **tier-assignment-guide.md** - How to distinguish Design vs Method vs Protocol
- **consolidation-patterns.md** - When to lump vs split items
- **expected-information.md** - Domain-specific completeness checklists (TIDieR, CONSORT-Outcomes adapted)

### Examples (`examples/`)

Worked extractions demonstrating:
- **sobotkova-example.md** - Complete RDMAP extraction from real paper
- Evidence/claim distinctions
- Three-tier hierarchy application
- Cross-reference patterns

## Usage Pattern

When working with extraction prompts:

1. **User provides extraction prompt** - Detailed instructions for specific pass
2. **Claude follows prompt** - Executes extraction according to provided instructions
3. **Claude consults skill references as needed:**
   - Uncertain about schema? → Read `schema/schema-guide.md`
   - Unsure about tier assignment? → Read `checklists/tier-assignment-guide.md`
   - Need consolidation guidance? → Read `checklists/consolidation-patterns.md`
   - Want to see examples? → Read `examples/sobotkova-example.md`

## Benefits of This Architecture

- **Separation of concerns:** Framework (stable) vs prompts (evolving)
- **Minimal versioning conflicts:** Prompt refinements don't require skill repackaging
- **Efficient context use:** Only load references when needed
- **Flexibility:** User controls prompt versions and variations
