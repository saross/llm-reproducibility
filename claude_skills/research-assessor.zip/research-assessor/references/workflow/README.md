# Workflow Prompts - Complete Extraction Guidance

This directory contains the complete extraction prompts for all five passes of the Research Assessor workflow.

## Available Prompts

1. **claims-pass1.md** - Liberal Claims/Evidence Extraction (~800 lines)
2. **claims-pass2.md** - Claims/Evidence Rationalization (~900 lines)
3. **rdmap-pass1.md** - Liberal RDMAP Extraction (~1000 lines)
4. **rdmap-pass2.md** - RDMAP Rationalization (~900 lines)
5. **validation-pass3.md** - Integrity Validation (~600 lines)

## Prompt Structure

Each prompt contains:

**Pass 1 Prompts (Liberal Extraction):**
- Extraction philosophy ("when uncertain, include it")
- Core extraction principles
- Decision frameworks (evidence vs claims, tier assignment)
- Extensive examples with correct/incorrect patterns
- Expected information checklists
- Quality criteria
- Output format specification

**Pass 2 Prompts (Rationalization):**
- Rationalization philosophy (15-20% reduction target)
- Consolidation decision frameworks
- When to lump vs split guidance
- Consolidation metadata requirements
- Quality verification steps
- Addition patterns (missing implicit claims)

**Pass 3 Prompt (Validation):**
- Cross-reference integrity checks
- Hierarchy validation rules
- Schema compliance verification
- Expected information review
- Validation report format

## Complete Prompts Available

The FULL prompts (~4000+ total lines with all examples and guidance) are available in the project knowledge as:

- `Claims/Evidence Pass 1 v2.4 (Updated for Iterative Workflow).md`
- `Claims/Evidence Pass 2 v2.4 (Updated for Iterative Workflow).md`
- `Pass 1: RDMAP Liberal Extraction Prompt v2.4.md`
- `Pass 2: RDMAP Rationalization Prompt v2.4.md`
- `Pass 3: RDMAP Validation Prompt v2.4.md`

These can be copied directly from project knowledge into this directory for the complete, unabridged versions.

## Usage

When Claude processes a task:
1. SKILL.md identifies which pass is needed
2. Claude reads the appropriate prompt file from this directory
3. Claude follows the extraction guidance
4. Claude returns the updated JSON document

The prompts are designed to work with the iterative accumulation workflow where a single JSON document flows through all passes.

## Note on File Sizes

Due to their comprehensiveness, these prompt files are substantial:
- Each contains 400-1000 lines of detailed guidance
- Include extensive examples and decision trees
- Provide domain-specific checklists
- Total ~4000+ lines across all five prompts

This completeness ensures high-quality, consistent extractions across different papers and domains.
