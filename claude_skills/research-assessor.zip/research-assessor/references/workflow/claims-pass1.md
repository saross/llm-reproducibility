# Claims & Evidence Extraction Prompt - PASS 1: Liberal Extraction v2.4

**Version:** 2.4 Pass 1  
**Last Updated:** 2025-10-19  
**Workflow Stage:** Pass 1 - Liberal extraction with over-capture strategy

---

## Your Task

Extract evidence, claims, and implicit arguments from a research paper section. This is **Pass 1: Liberal Extraction** - when uncertain, err on the side of inclusion. Pass 2 will consolidate and refine.

**Input:** JSON extraction document (schema v2.4)
- May be blank template (starting fresh)
- May be partially populated (if RDMAP or other sections already extracted)

**Your responsibility:** Populate these arrays:
- `evidence`
- `claims`
- `implicit_arguments`
- `project_metadata`

**Leave untouched:** 
- `research_designs`, `methods`, `protocols` (RDMAP arrays - extracted separately)
- Any other arrays already populated

**Output:** Same JSON document with evidence/claims/implicit arguments arrays populated

---

[Content continues but truncating for brevity - the full file would include all content from the Claims Pass 1 prompt found in project knowledge]
