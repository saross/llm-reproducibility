# Research Assessment Schema v2.4 - Complete Guide

## Overview

This schema defines six object types for extracting research methodology and argumentation:

**Claims & Evidence:**
- `evidence` - Raw observations, measurements, data
- `claims` - Assertions that interpret or generalize
- `implicit_arguments` - Unstated assumptions and logical implications

**RDMAP (Research Design, Methods, Protocols):**
- `research_designs` - Strategic decisions (WHY research framed this way)
- `methods` - Tactical approaches (WHAT was done at high level)
- `protocols` - Operational procedures (HOW specifically implemented)

## Complete JSON Structure

```json
{
  "schema_version": "2.4",
  "extraction_timestamp": "ISO 8601 datetime",
  "extractor": "Claude Sonnet 4.5",
  
  "evidence": [evidence_object],
  "claims": [claim_object],
  "implicit_arguments": [implicit_argument_object],
  
  "research_designs": [research_design_object],
  "methods": [method_object],
  "protocols": [protocol_object],
  
  "project_metadata": {
    "timeline": {},
    "location": {},
    "resources": {},
    "track_record": {}
  },
  
  "extraction_notes": {
    "pass": 1 | 2 | 3,
    "section_extracted": "string",
    "known_uncertainties": ["string"]
  }
}
```

## Evidence Object

**Purpose:** Raw observations, measurements, or data requiring minimal interpretation

**Required fields:**
- `evidence_id`: String matching pattern `E###` (E001, E002, ...)
- `evidence_text`: String describing the observation
- `evidence_type`: Enum of observation types

**Key fields:**
- `declared_uncertainty`: Author-stated uncertainty (ranges, confidence intervals)
- `expected_uncertainty_missing`: Uncertainty we would expect but is absent
- `supports_claims`: Array of claim IDs `["C001", "C005"]`
- `related_evidence`: Array for analytical views `["E002"]`
- `location`: `{section, page, paragraph}`
- `consolidation_metadata`: Traceability for consolidated items

**Example:**
```json
{
  "evidence_id": "E001",
  "evidence_text": "Survey collected 8,343 features across 22 sites",
  "evidence_type": "quantitative_observation",
  "supports_claims": ["C015"],
  "location": {"section": "Results", "page": 8, "paragraph": 2}
}
```

## Claim Object

**Purpose:** Assertions that interpret, frame, or generalize from evidence

**Required fields:**
- `claim_id`: String matching pattern `C###`
- `claim_text`: String stating the assertion
- `claim_type`: `empirical | interpretation | methodological_argument | theoretical`
- `claim_role`: `core | intermediate | supporting`

**Key fields:**
- `supported_by_evidence`: Array of evidence IDs `["E001", "E003"]`
- `supported_by_claims`: Array of supporting claim IDs
- `supports_claims`: Array of claims this supports
- `implicit_assumptions`: Array of implicit argument IDs `["IA001"]`
- `author_confidence`: `definite | probable | speculative | hedged`
- `expected_information_missing`: Gaps in justification

**Example:**
```json
{
  "claim_id": "C015",
  "claim_text": "Mobile platform enabled large-scale data collection with minimal supervision",
  "claim_type": "interpretation",
  "claim_role": "intermediate",
  "supported_by_evidence": ["E001", "E012"],
  "supports_claims": ["C001"],
  "location": {"section": "Discussion", "page": 12, "paragraph": 1}
}
```

## Implicit Argument Object

**Purpose:** Unstated assumptions, logical implications, bridging claims

**Types:**
- `logical_implication`: IF explicit claims true THEN X must be true
- `unstated_assumption`: Prerequisites assumed without acknowledgment
- `bridging_claim`: Missing links between evidence and conclusions
- `design_assumption`: Assumptions about research design choices
- `methodological_assumption`: Assumptions about method validity

**Example:**
```json
{
  "implicit_argument_id": "IA001",
  "argument_text": "GPS accuracy is sufficient for archaeological survey purposes",
  "type": "methodological_assumption",
  "supports_claims": ["C008"],
  "disciplinary_context": "archaeology"
}
```

## Research Design Object

**Purpose:** Strategic decisions about WHY research was framed this way

**Required fields:**
- `design_id`: String matching pattern `RD###`
- `design_text`: Description of the design decision
- `design_type`: `research_question | theoretical_framework | study_design | scope_definition | positionality`

**Key fields:**
- `enables_methods`: Array of method IDs this design enables
- `reasoning_approach`: `inductive | deductive | abductive | mixed`
- `hypothesis_timing`: When hypotheses were formulated
- `implicit_assumptions`: Design assumptions

**Example:**
```json
{
  "design_id": "RD001",
  "design_text": "Comparative study of mobile vs traditional data collection",
  "design_type": "study_design",
  "study_design": {
    "design_type": "comparative",
    "rationale": "Test mobile platform effectiveness"
  },
  "enables_methods": ["M003", "M008"],
  "reasoning_approach": {"approach": "abductive"}
}
```

## Method Object

**Purpose:** Tactical approaches about WHAT was done at high level

**Required fields:**
- `method_id`: String matching pattern `M###`
- `method_text`: Description of the method
- `method_type`: `data_collection | sampling | analysis | quality_control | validation`

**Key fields:**
- `implements_designs`: Which designs this method implements
- `realized_through_protocols`: Which protocols implement this method
- `validated_by_evidence`: Evidence of method effectiveness
- `justification_claim`: Claim justifying method choice

**Example:**
```json
{
  "method_id": "M008",
  "method_text": "Mobile platform (FAIMS) for field data collection",
  "method_type": "data_collection",
  "implements_designs": ["RD001"],
  "realized_through_protocols": ["P023", "P024"],
  "validated_by_evidence": ["E046"]
}
```

## Protocol Object

**Purpose:** Operational procedures about HOW specifically it was done

**Required fields:**
- `protocol_id`: String matching pattern `P###`
- `protocol_text`: Detailed procedure description
- `protocol_type`: Type of protocol

**Key fields:**
- `implements_methods`: Which method(s) this protocol implements
- `produces_evidence`: Evidence produced by this protocol
- `tools`: Array of tools/instruments used
- `measurement_specification`: Detailed measurement parameters

**Example:**
```json
{
  "protocol_id": "P023",
  "protocol_text": "FAIMS Mobile v2.6 configured for archaeological survey",
  "protocol_type": "recording",
  "tools": [{
    "tool_name": "FAIMS Mobile",
    "version": "2.6",
    "configuration": "Custom archaeological module"
  }],
  "implements_methods": ["M008"],
  "produces_evidence": ["E045"]
}
```

## Cross-Reference Architecture

All cross-references use simple string ID arrays:

**Claims reference evidence:**
```json
"supported_by_evidence": ["E001", "E003", "E012"]
```

**Evidence references claims:**
```json
"supports_claims": ["C015", "C027"]
```

**RDMAP hierarchy:**
```json
// Design enables methods
"enables_methods": ["M003", "M007"]

// Method implements designs and uses protocols
"implements_designs": ["RD001"]
"realized_through_protocols": ["P011", "P012"]

// Protocol implements methods
"implements_methods": ["M003"]
```

**Cross-domain references:**
```json
// Method validated by evidence
"validated_by_evidence": ["E046"]

// Method justified by claim
"justification_claim": "C027"

// Claim supports method
"supports_method": "M003"
```

## Consolidation Metadata

All consolidated items must include:

```json
"consolidation_metadata": {
  "consolidated_from": ["P1_E001", "P1_E002"],
  "consolidation_type": "granularity_reduction | compound_finding | ...",
  "information_preserved": "complete | lossy_granularity | lossy_redundancy",
  "granularity_available": "Description of finer detail in source",
  "rationale": "Why consolidation was appropriate"
}
```

## Location Tracking

All objects include location for traceability:

```json
"location": {
  "section": "Methods",
  "page": 5,
  "paragraph": 2,
  "sentence": 3  // optional
}
```

## For Complete Schema

Full JSON schema definitions with all fields, types, and constraints are available in:
- `schema-v2.4-claims.json` (Evidence, Claims, Implicit Arguments)
- `schema-v2.4-rdmap.json` (Research Designs, Methods, Protocols)

These files are in the project knowledge and can be consulted for comprehensive field definitions.
