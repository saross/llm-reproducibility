---
name: research-assessor
description: Extracts and assesses research methodology, claims, and evidence from fieldwork-based research papers. Evaluates transparency, replicability, and credibility through systematic extraction of research designs, methods, protocols, claims, and evidence using a five-pass iterative workflow.
---

# Research Assessor

Systematic extraction and assessment framework for research methodology, claims, and evidence in fieldwork-based disciplines (archaeology, biology, ethnography, ecology, etc.).

## What This Skill Does

This skill enables comprehensive extraction of research methodology and argumentation from academic papers through a structured multi-pass workflow:

1. **Claims & Evidence Extraction** (Pass 1 & 2) - Extract observations, measurements, claims, and implicit arguments
2. **RDMAP Extraction** (Pass 1 & 2) - Extract Research Designs, Methods, and Protocols  
3. **Validation** (Pass 3) - Verify structural integrity and cross-reference consistency

The extracted data enables assessment of research transparency, replicability, and credibility.

## When to Use This Skill

Use when users request:
- "Extract methodology from this paper"
- "Assess research transparency"
- "Extract claims and evidence"
- "Evaluate replicability"
- "Extract research designs and methods"
- Any task involving systematic analysis of research papers for methodology, argumentation, or credibility assessment

## Core Workflow

The complete extraction follows this sequence:

```
Blank JSON Template
    ↓
Claims/Evidence Pass 1 (liberal extraction)
    ↓
Claims/Evidence Pass 2 (rationalization)
    ↓
RDMAP Pass 1 (liberal extraction)
    ↓
RDMAP Pass 2 (rationalization)
    ↓
Validation Pass 3 (integrity checks)
    ↓
Assessment-Ready Extraction
```

**Key principle:** Single JSON document flows through all passes. Each pass populates or refines specific arrays, leaving others untouched.

## Using This Skill

### Architecture: Skill + Runtime Prompts

This skill provides:
- **Core decision frameworks** (how to distinguish evidence/claims, assign tiers, consolidate items)
- **Schema definitions** (object structures, field requirements)
- **Reference materials** (checklists, examples)

The user provides:
- **Extraction prompts** (detailed instructions for each pass, provided at runtime)
- **Source material** (research paper sections to extract from)
- **JSON document** (template or partially populated from previous passes)

**Why this separation?** Extraction prompts evolve frequently through testing and refinement. This architecture allows prompt tuning without modifying the skill package, minimizing versioning conflicts.

### Step 1: Identify the Task

Users will typically request extraction at a specific pass. Listen for:
- "Extract claims/evidence Pass 1" → Liberal claims extraction
- "Rationalize the claims" → Claims Pass 2
- "Extract RDMAP" → RDMAP Pass 1
- "Extract methodology" → RDMAP Pass 1
- "Validate the extraction" → Pass 3

### Step 2: Receive the Extraction Prompt

The user will provide the extraction prompt for the specific pass they want. These prompts are:

**Claims/Evidence Extraction:**
- **Pass 1:** Liberal extraction prompt (comprehensive capture with over-extraction)
- **Pass 2:** Rationalization prompt (consolidation and refinement)

**RDMAP Extraction:**
- **Pass 1:** Liberal extraction prompt (three-tier hierarchy with over-extraction)
- **Pass 2:** Rationalization prompt (consolidation and verification)

**Validation:**
- **Pass 3:** Unified validation prompt (structural integrity checks across all arrays)

The prompts contain detailed instructions, examples, and decision frameworks for that specific extraction pass. Follow the prompt provided.

### Step 3: Consult Supporting References As Needed

If you encounter uncertainty during extraction, consult:

**Schema & Structure:**
- `references/schema/schema-guide.md` - Complete object definitions
- `references/schema/examples/` - JSON examples from real extractions

**Decision Frameworks:**
- `references/checklists/tier-assignment-guide.md` - Design vs Method vs Protocol decisions
- `references/checklists/consolidation-patterns.md` - When to lump vs split items
- `references/checklists/expected-information.md` - Domain-specific completeness checklists

**Examples:**
- `references/examples/sobotkova-methods.md` - Complete worked example

### Step 4: Execute and Return

Follow the workflow guidance to:
1. Extract or rationalize content
2. Populate appropriate arrays in JSON
3. Leave other arrays untouched
4. Return the updated JSON document

## Key Extraction Principles

### Iterative Accumulation
- Single JSON document flows through all passes
- Each pass handles specific arrays only
- No merging step needed
- Flexible ordering (claims first OR RDMAP first)

### Liberal Then Rationalize
- **Pass 1:** Over-extract (40-50% more items expected) - comprehensive capture
- **Pass 2:** Consolidate (15-20% reduction target) - refined quality

### Separation of Concerns
- **Claims/Evidence passes:** Touch evidence, claims, implicit_arguments arrays ONLY
- **RDMAP passes:** Touch research_designs, methods, protocols arrays ONLY
- **Validation pass:** Reads all, modifies none

### Cross-Reference Architecture
- Simple string ID arrays: `["M003", "M007"]`
- Bidirectional consistency enforced
- Works across object types (methods reference claims, protocols reference evidence)

## Core Decision Frameworks

### Evidence vs. Claims

**Evidence** = Raw observations requiring minimal interpretation
- Direct measurements, observations, data points
- Someone could verify by checking the source
- Example: "125.8 person-hours" or "12 students owned smartphones"

**Claims** = Assertions that interpret or generalize
- Require reasoning or expertise to assess
- Make inferences beyond direct observation
- Example: "The platform was efficient" or "Data quality was high"

**Test:** "Does this require expertise to assess or just checking sources?"

### RDMAP Three-Tier Hierarchy

**Research Designs** (Strategic - WHY)
- Research questions and hypotheses
- Theoretical frameworks
- Study design choices
- **Test:** "Is this about framing and rationale?"

**Methods** (Tactical - WHAT)
- Data collection approaches
- Sampling strategies
- Analysis techniques
- **Test:** "Is this the general approach at high level?"

**Protocols** (Operational - HOW)
- Specific procedures
- Tool configurations
- Parameter specifications  
- **Test:** "Could someone replicate from this level of detail?"

### Consolidation Logic

**Acid Test:** "Would I assess these items TOGETHER or SEPARATELY?"
- Together → Consolidate
- Separately → Keep distinct

**Match granularity to assessment needs:**
- If claim assesses components together → consolidate evidence
- If claim needs separate assessment → keep evidence separate
- Balance readability with traceability

## Important Notes

**For testing/debugging:**
- Can validate partial extractions (RDMAP-only or claims-only)
- Each pass can be tested independently
- Start with blank template OR pre-populated arrays

**Expected outcomes:**
- Pass 1: Comprehensive (intentional over-capture)
- Pass 2: ~15-20% reduction through consolidation
- Pass 3: Validation report (no modifications)

**Token efficiency:**
- Only load workflow file needed for current pass
- Schema/examples load only when uncertain
- Minimal context bloat

## Quick Reference

**Common user patterns:**
- User provides extraction prompt + source material → Extract according to prompt
- "Help me understand this extraction" → Consult schema and examples
- "Should I consolidate these?" → Check consolidation-patterns.md
- "Is this a Design, Method, or Protocol?" → Check tier-assignment-guide.md
- "What information is expected?" → Check expected-information.md

**Working with prompts:**
- User provides the full extraction prompt for the current pass
- Follow the prompt's instructions precisely
- Use skill references to resolve ambiguities
- Document uncertainties in extraction_notes

**Always:**
- Preserve other arrays unchanged
- Document consolidations with metadata
- Flag uncertainties in extraction_notes
- Return complete JSON document

---

**The user will provide the detailed extraction prompt for each pass. Use this skill's reference materials to support decision-making during extraction.**
